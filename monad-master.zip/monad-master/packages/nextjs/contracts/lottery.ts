// 抽奖合约配置
export const LOTTERY_CONTRACT = {
  address: "0x1234567890123456789012345678901234567890", // 替换为实际部署的合约地址
  abi: [
    {
      inputs: [{ name: "_ticketPrice", type: "uint256" }],
      stateMutability: "nonpayable",
      type: "constructor"
    },
    {
      inputs: [],
      name: "enter",
      outputs: [],
      stateMutability: "payable",
      type: "function"
    },
    {
      inputs: [],
      name: "drawWinner",
      outputs: [],
      stateMutability: "nonpayable",
      type: "function"
    },
    {
      inputs: [],
      name: "startNewLottery",
      outputs: [],
      stateMutability: "nonpayable",
      type: "function"
    },
    {
      inputs: [],
      name: "getPlayers",
      outputs: [{ name: "", type: "address[]" }],
      stateMutability: "view",
      type: "function"
    },
    {
      inputs: [],
      name: "getBalance",
      outputs: [{ name: "", type: "uint256" }],
      stateMutability: "view",
      type: "function"
    },
    {
      inputs: [],
      name: "ticketPrice",
      outputs: [{ name: "", type: "uint256" }],
      stateMutability: "view",
      type: "function"
    },
    {
      inputs: [],
      name: "isActive",
      outputs: [{ name: "", type: "bool" }],
      stateMutability: "view",
      type: "function"
    },
    {
      inputs: [],
      name: "owner",
      outputs: [{ name: "", type: "address" }],
      stateMutability: "view",
      type: "function"
    },
    {
      anonymous: false,
      inputs: [
        { indexed: false, name: "player", type: "address" }
      ],
      name: "PlayerEntered",
      type: "event"
    },
    {
      anonymous: false,
      inputs: [
        { indexed: false, name: "winner", type: "address" },
        { indexed: false, name: "amount", type: "uint256" }
      ],
      name: "WinnerSelected",
      type: "event"
    }
  ]
} as const;