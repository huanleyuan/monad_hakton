
"use client";

import { useAccount } from "wagmi";
import { Address } from "~~/components/scaffold-eth";
import type { NextPage } from "next";
import Link from "next/link";
import { BugAntIcon, MagnifyingGlassIcon } from "@heroicons/react/24/outline";


const Home: NextPage = () => {
  const { address: connectedAddress } = useAccount();

  return (
    <>
     <p className="text-center text-lg">
                体验去中心化抽奖游戏{" "}
                <Link href="/lottery" passHref className="link">
                  区块链抽奖
                </Link>{" "}
                页面。
              </p>
    </>
  );
};

export default Home;
