"use client";

import { LotteryPage } from "~~/components/LotteryPage";
import type { NextPage } from "next";

const Lottery: NextPage = () => {
  return <LotteryPage />;
};

export default Lottery;