import React, { useState, useEffect } from 'react';
import { useAccount, useWriteContract, useReadContract, useWatchContractEvent } from 'wagmi';
import { parseEther, formatEther } from 'viem';
import { useConnectModal } from '@rainbow-me/rainbowkit';
import { toast } from 'react-hot-toast';

const LOTTERY_ABI = [
  {
    inputs: [],
    name: "enter",
    outputs: [],
    stateMutability: "payable",
    type: "function"
  },
  {
    inputs: [],
    name: "drawWinner",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  },
  {
    inputs: [],
    name: "startNewLottery",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  },
  {
    inputs: [],
    name: "getPlayers",
    outputs: [{ type: "address[]" }],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [],
    name: "getBalance",
    outputs: [{ type: "uint256" }],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [],
    name: "ticketPrice",
    outputs: [{ type: "uint256" }],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [],
    name: "isActive",
    outputs: [{ type: "bool" }],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [],
    name: "owner",
    outputs: [{ type: "address" }],
    stateMutability: "view",
    type: "function"
  },
  {
    anonymous: false,
    inputs: [
      { indexed: false, name: "player", type: "address" }
    ],
    name: "PlayerEntered",
    type: "event"
  },
  {
    anonymous: false,
    inputs: [
      { indexed: false, name: "winner", type: "address" },
      { indexed: false, name: "amount", type: "uint256" }
    ],
    name: "WinnerSelected",
    type: "event"
  }
] as const;

const LOTTERY_ADDRESS = "0x1234567890123456789012345678901234567890"; // 替换为实际合约地址

export const LotteryPage: React.FC = () => {
  const [isSpinning, setIsSpinning] = useState(false);
  const [lastWinner, setLastWinner] = useState<string | null>(null);
  const [winAmount, setWinAmount] = useState<string | null>(null);
  
  const { address, isConnected } = useAccount();
  const { openConnectModal } = useConnectModal();
  const { writeContract, isPending } = useWriteContract();

  const { data: ticketPrice } = useReadContract({
    address: LOTTERY_ADDRESS,
    abi: LOTTERY_ABI,
    functionName: 'ticketPrice',
  });

  const { data: players } = useReadContract({
    address: LOTTERY_ADDRESS,
    abi: LOTTERY_ABI,
    functionName: 'getPlayers',
  });

  const { data: balance } = useReadContract({
    address: LOTTERY_ADDRESS,
    abi: LOTTERY_ABI,
    functionName: 'getBalance',
  });

  const { data: isActive } = useReadContract({
    address: LOTTERY_ADDRESS,
    abi: LOTTERY_ABI,
    functionName: 'isActive',
  });

  const { data: owner } = useReadContract({
    address: LOTTERY_ADDRESS,
    abi: LOTTERY_ABI,
    functionName: 'owner',
  });

  const isOwner = address && owner && address.toLowerCase() === owner.toLowerCase();
  const playerCount = players?.length || 0;
  const hasJoined = players?.some(player => player.toLowerCase() === address?.toLowerCase());

  // 监听事件
  useWatchContractEvent({
    address: LOTTERY_ADDRESS,
    abi: LOTTERY_ABI,
    eventName: 'PlayerEntered',
    onLogs(logs) {
      toast.success('新玩家加入抽奖！');
    },
  });

  useWatchContractEvent({
    address: LOTTERY_ADDRESS,
    abi: LOTTERY_ABI,
    eventName: 'WinnerSelected',
    onLogs(logs) {
      const log = logs[0];
      if (log?.args) {
        const { winner, amount } = log.args;
        setLastWinner(winner as string);
        setWinAmount(formatEther(amount as bigint));
        setIsSpinning(false);
        toast.success(`🎉 恭喜 ${winner?.slice(0, 6)}...${winner?.slice(-4)} 中奖！`);
      }
    },
  });

  const enterLottery = async () => {
    if (!ticketPrice) return;
    
    try {
      await writeContract({
        address: LOTTERY_ADDRESS,
        abi: LOTTERY_ABI,
        functionName: 'enter',
        value: ticketPrice,
      });
      toast.success('成功参与抽奖！');
    } catch (error) {
      toast.error('参与抽奖失败');
    }
  };

  const drawWinner = async () => {
    setIsSpinning(true);
    try {
      await writeContract({
        address: LOTTERY_ADDRESS,
        abi: LOTTERY_ABI,
        functionName: 'drawWinner',
      });
    } catch (error) {
      setIsSpinning(false);
      toast.error('开奖失败');
    }
  };

  const startNewLottery = async () => {
    try {
      await writeContract({
        address: LOTTERY_ADDRESS,
        abi: LOTTERY_ABI,
        functionName: 'startNewLottery',
      });
      setLastWinner(null);
      setWinAmount(null);
      toast.success('新一轮抽奖开始！');
    } catch (error) {
      toast.error('启动新抽奖失败');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 flex items-center justify-center p-4">
      <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-8 shadow-2xl max-w-lg w-full border border-white/20">
        {/* 标题 */}
        <div className="text-center mb-8">
          <div className="text-6xl mb-4 animate-bounce">🎰</div>
          <h1 className="text-4xl font-bold text-white mb-2">区块链抽奖</h1>
          <p className="text-white/70">去中心化的公平抽奖</p>
        </div>

        {!isConnected ? (
          <div className="text-center">
            <button 
              onClick={openConnectModal}
              className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-8 py-4 rounded-2xl text-lg font-semibold hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-purple-500/25"
            >
              🔗 连接钱包开始游戏
            </button>
          </div>
        ) : (
          <div>
            {/* 用户信息 */}
            <div className="mb-6 p-4 bg-white/10 rounded-2xl border border-white/20">
              <div className="flex items-center justify-between">
                <span className="text-white/70 text-sm">钱包地址</span>
                <span className="text-white font-mono text-sm">
                  {address?.slice(0, 6)}...{address?.slice(-4)}
                </span>
              </div>
              {hasJoined && (
                <div className="mt-2 text-center">
                  <span className="inline-block bg-green-500/20 text-green-300 px-3 py-1 rounded-full text-xs">
                    ✅ 已参与抽奖
                  </span>
                </div>
              )}
            </div>

            {/* 抽奖信息 */}
            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="bg-white/10 p-4 rounded-2xl border border-white/20 text-center">
                <div className="text-2xl mb-2">💰</div>
                <p className="text-white/70 text-sm mb-1">票价</p>
                <p className="text-white font-bold text-lg">
                  {ticketPrice ? formatEther(ticketPrice) : '0'} ETH
                </p>
              </div>
              <div className="bg-white/10 p-4 rounded-2xl border border-white/20 text-center">
                <div className="text-2xl mb-2">👥</div>
                <p className="text-white/70 text-sm mb-1">参与人数</p>
                <p className="text-white font-bold text-lg">{playerCount}</p>
              </div>
              <div className="bg-white/10 p-4 rounded-2xl border border-white/20 text-center">
                <div className="text-2xl mb-2">🏆</div>
                <p className="text-white/70 text-sm mb-1">奖池</p>
                <p className="text-white font-bold text-lg">
                  {balance ? formatEther(balance) : '0'} ETH
                </p>
              </div>
              <div className="bg-white/10 p-4 rounded-2xl border border-white/20 text-center">
                <div className="text-2xl mb-2">{isActive ? '🟢' : '🔴'}</div>
                <p className="text-white/70 text-sm mb-1">状态</p>
                <p className={`font-bold text-lg ${isActive ? 'text-green-400' : 'text-red-400'}`}>
                  {isActive ? '进行中' : '已结束'}
                </p>
              </div>
            </div>

            {/* 上期中奖信息 */}
            {lastWinner && winAmount && (
              <div className="mb-6 p-4 bg-gradient-to-r from-yellow-500/20 to-orange-500/20 rounded-2xl border border-yellow-500/30">
                <div className="text-center">
                  <div className="text-3xl mb-2">🎉</div>
                  <p className="text-yellow-300 text-sm mb-1">上期中奖者</p>
                  <p className="text-white font-mono text-sm mb-2">
                    {lastWinner.slice(0, 6)}...{lastWinner.slice(-4)}
                  </p>
                  <p className="text-yellow-300 font-bold">{winAmount} ETH</p>
                </div>
              </div>
            )}

            {/* 操作按钮 */}
            <div className="space-y-4">
              {isActive && (
                <button 
                  onClick={enterLottery}
                  disabled={isPending || hasJoined}
                  className="w-full bg-gradient-to-r from-green-500 to-emerald-500 text-white px-6 py-4 rounded-2xl text-lg font-semibold hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 shadow-lg hover:shadow-green-500/25"
                >
                  {isPending ? (
                    <span className="flex items-center justify-center">
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                      处理中...
                    </span>
                  ) : hasJoined ? (
                    '✅ 已参与抽奖'
                  ) : (
                    `🎫 参与抽奖 (${ticketPrice ? formatEther(ticketPrice) : '0'} ETH)`
                  )}
                </button>
              )}
              
              {isOwner && isActive && playerCount > 0 && (
                <button 
                  onClick={drawWinner}
                  disabled={isPending || isSpinning}
                  className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-6 py-4 rounded-2xl text-lg font-semibold hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 shadow-lg hover:shadow-yellow-500/25"
                >
                  {isPending || isSpinning ? (
                    <span className="flex items-center justify-center">
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                      {isSpinning ? '🎰 开奖中...' : '处理中...'}
                    </span>
                  ) : (
                    '🎯 立即开奖'
                  )}
                </button>
              )}

              {isOwner && !isActive && (
                <button 
                  onClick={startNewLottery}
                  disabled={isPending}
                  className="w-full bg-gradient-to-r from-blue-500 to-purple-500 text-white px-6 py-4 rounded-2xl text-lg font-semibold hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 shadow-lg hover:shadow-blue-500/25"
                >
                  {isPending ? (
                    <span className="flex items-center justify-center">
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                      启动中...
                    </span>
                  ) : (
                    '🚀 开始新一轮抽奖'
                  )}
                </button>
              )}
            </div>

            {/* 游戏规则 */}
            <div className="mt-8 p-4 bg-white/5 rounded-2xl border border-white/10">
              <h3 className="text-white font-semibold mb-3 text-center">📋 游戏规则</h3>
              <ul className="text-white/70 text-sm space-y-1">
                <li>• 支付固定票价参与抽奖</li>
                <li>• 所有参与费用进入奖池</li>
                <li>• 管理员开奖时随机选择中奖者</li>
                <li>• 中奖者获得全部奖池金额</li>
                <li>• 基于区块链，公开透明</li>
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default LotteryPage;