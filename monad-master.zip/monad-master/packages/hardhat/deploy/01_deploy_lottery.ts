import { HardhatRuntimeEnvironment } from "hardhat/types";
import { DeployFunction } from "hardhat-deploy/types";
import { ethers } from "hardhat";

const deployLottery: DeployFunction = async function (hre: HardhatRuntimeEnvironment) {
  const { deployer } = await hre.getNamedAccounts();
  const { deploy } = hre.deployments;

  const ticketPrice = ethers.parseEther("0.01"); // 0.01 ETH per ticket

  await deploy("Lottery", {
    from: deployer,
    args: [ticketPrice],
    log: true,
    autoMine: true,
  });

  const lottery = await hre.ethers.getContract("Lottery", deployer);
  console.log("👋 Lottery deployed at:", await lottery.getAddress());
  console.log("🎫 Ticket price:", ethers.formatEther(ticketPrice), "ETH");
};

export default deployLottery;
deployLottery.tags = ["Lottery"];