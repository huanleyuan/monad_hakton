import { expect } from "chai";
import { ethers } from "hardhat";
import { Lottery } from "../typechain-types";

describe("Lottery", function () {
  let lottery: Lottery;
  let owner: any;
  let player1: any;
  let player2: any;
  const ticketPrice = ethers.parseEther("0.01");

  beforeEach(async function () {
    [owner, player1, player2] = await ethers.getSigners();
    
    const LotteryFactory = await ethers.getContractFactory("Lottery");
    lottery = await LotteryFactory.deploy(ticketPrice);
  });

  it("Should allow players to enter", async function () {
    await lottery.connect(player1).enter({ value: ticketPrice });
    expect(await lottery.getPlayerCount()).to.equal(1);
  });

  it("Should reject incorrect ticket price", async function () {
    await expect(
      lottery.connect(player1).enter({ value: ethers.parseEther("0.02") })
    ).to.be.revertedWith("Incorrect ticket price");
  });

  it("Should draw winner and transfer prize", async function () {
    await lottery.connect(player1).enter({ value: ticketPrice });
    await lottery.connect(player2).enter({ value: ticketPrice });
    
    const initialBalance = await ethers.provider.getBalance(player1.address);
    
    await lottery.drawWinner();
    
    expect(await lottery.isActive()).to.be.false;
  });
});